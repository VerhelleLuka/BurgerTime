#pragma once
enum EventType
{
	LOSTLIFE,
	GAINEDPOINTS,
	STATECHANGED
};